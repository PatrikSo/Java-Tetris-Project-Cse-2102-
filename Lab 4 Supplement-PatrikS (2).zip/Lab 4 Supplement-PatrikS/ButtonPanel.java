
/**
 * Write a description of class ButtonPanel here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;


public class ButtonPanel extends JPanel{
    JButton _openButton, _saveButton;
    DrawingPanel _dp;
    ButtonListener bl = new ButtonListener();
    JFileChooser _fc = new JFileChooser();


public ButtonPanel(DrawingPanel dp){
    super();
    
    _dp = dp;
    _openButton = new JButton("Open File");
    _saveButton = new JButton("Save File");
    _openButton.addActionListener(bl);
    _saveButton.addActionListener(bl);
    add(_openButton);
    add(_saveButton);
}


public class ButtonListener implements ActionListener{
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == _openButton){
            _dp.loadFromFile();
            _dp.requestFocus();
        }else if (e.getSource() == _saveButton){
            _dp.saveToFile();
            _dp.requestFocus();
        }
        }
}
}