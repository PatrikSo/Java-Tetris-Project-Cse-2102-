import java.awt.event.*;
import javax.swing.event.*;
    public class MyMouseListener extends MouseAdapter
    {
        DrawingPanel _myPanel;        
        // constructor
        public MyMouseListener(DrawingPanel dp)
        {
            _myPanel = dp;
        }
        public void mouseClicked(MouseEvent e)
        {
            _myPanel.mouseClicked(e);
        }
    }