    /** Drawing Panel displays the circles the user has created via mouse clicks
 * 
 * @author (Greg Johnson) 
 * @version (November 1, 2017)
 */
import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;



public class DrawingPanel extends JPanel 
{
        SmartEllipse    _circle = null;
        private KeyInteractor _sListener, _oListener;
        private Random _rand;
        ArrayList<SmartEllipse> _circleList = new ArrayList<SmartEllipse>();
    /**
     * Constructor for objects of class ObjectPanel
     */
    public DrawingPanel()
    {
        super();
        
        _sListener = new KeySListener(this);
        _oListener = new KeyOListener(this);
 
        MyMouseListener myMouseListener = new MyMouseListener(this);
        
        // set up the display on the panel
        this.setBackground(Color.WHITE);

        // add the panel as a MouseListener
        this.addMouseListener(myMouseListener);
    }
   
    /**
     * The paintComponent method of class DrawingPanel is responsible for painting
     * the panel any time there is a change in the panel.
     */
    public void paintComponent(Graphics aBrush)
    {
        super.paintComponent(aBrush);
        Graphics2D aBetterBrush = (Graphics2D)aBrush;
        Iterator<SmartEllipse> _iterator = _circleList.iterator(); //Array method
        while(_iterator.hasNext()){
            _iterator.next().fill(aBetterBrush);
        }
        
    }
     
    /**
     * The mouseClicked method will create a new SmartEllipse
     * and (eventually) add it to the ArrayList of dots in the drawing area
     */
     public void mouseClicked(java.awt.event.MouseEvent e)
     {
        _rand = new Random();
        
        int _red = _rand.nextInt(256);
        int _blue = _rand.nextInt(256);
        int _green = _rand.nextInt(256);
        
         Point currentPoint;
        // get the current mouse location
        currentPoint = e.getPoint();

        //create a new circle and put draw it on the panel
        _circle = new SmartEllipse(new Color(_red, _green, _blue));
        _circle.setSize(20,20);                         //dot on screen is 20 by 20 pixels
        _circle.setLocation(currentPoint.x-10, currentPoint.y-10);  //subtracting 10 from x and y centers the circle on the mouse click
        
        _circleList.add(_circle);
        
        repaint();  
        
    }   
    
    public void saveToFile(){
        JFileChooser fc = new JFileChooser();
        
        int returnValue = fc.showSaveDialog(this);
        
        if(returnValue == JFileChooser.APPROVE_OPTION){
            File file = fc.getSelectedFile();
            
            saveToFile(file);
        }
    }
    
    public void saveToFile(File f){
        try{
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f));
            
            os.writeObject(_circleList);
            os.close();
        }catch(java.io.IOException e){
            System.out.println("IO Exception reading file");
        }
    }
    
    public void loadFromFile(){
        JFileChooser fc = new JFileChooser();
        
        int returnValue = fc.showOpenDialog(this);
        
        if(returnValue == JFileChooser.APPROVE_OPTION){
            File file = fc.getSelectedFile();
            
            loadFromFile(file);
        }
    }
    
    public void loadFromFile(File f){
            try{
                ObjectInputStream is = new ObjectInputStream(new FileInputStream(f));
        
                _circleList = (ArrayList<SmartEllipse>)is.readObject();
                is.close();
            }catch(java.io.IOException e){
                System.out.println("IO Exception reading file");
            }catch(ClassNotFoundException e){
                System.out.println("Class Not Found Exception reading file");
            }
            repaint();
    }
    
    private class KeySListener extends KeyInteractor{
        public KeySListener(JPanel p)
        {
            super(p, KeyEvent.VK_S);
        }
    
        public void actionPerformed(ActionEvent e)
        {
            saveToFile();
        }
    }
    private class KeyOListener extends KeyInteractor{
        public KeyOListener(JPanel p)
        {
            super(p, KeyEvent.VK_O);
        }
    
        public void actionPerformed(ActionEvent e)
        {
            loadFromFile();
        }
    }
}
