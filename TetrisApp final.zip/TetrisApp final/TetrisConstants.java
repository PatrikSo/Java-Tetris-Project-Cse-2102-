/**
 * Chapter 9: CopyOfSmartEllipse.java
 * Adds capabilities to the Java2D.Double ellipse.
 * Same as the class defined in Chapter 7.
 */
public class TetrisConstants{
    // instance variables - replace the example below with your own
    public static int BLOCK_SIZE = 50;
    
    
    }