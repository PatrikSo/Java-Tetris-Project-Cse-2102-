/**
 * Chapter 9: SmartEllipse.java
 * Adds capabilities to the Java2D.Double ellipse.
 * Same as the class defined in Chapter 7.
 */
public class I extends Tetrimino {
    //private int x, y;
    int size = TetrisConstants.BLOCK_SIZE;
    private java.awt.Color _cyan = new java.awt.Color(0,255,255);
    
    public I(int x, int y){
        //create blocks
        _block1 = new SmartRectangle(_cyan);
        _block2 = new SmartRectangle(_cyan);
        _block3 = new SmartRectangle(_cyan);
        _block4 = new SmartRectangle(_cyan);
       
        _block1.setSize(size,size);
        _block2.setSize(size,size);
        _block3.setSize(size,size);
        _block4.setSize(size,size);
           
        this.setLocation(x,y);
    }
 

    // more readable versions of methods provided by Java
    public void setLocation(int x, int y){
        //set location
        _block1.setLocation(x,y + (size*3));
        _block2.setLocation(x,y);
        _block3.setLocation(x,y + (size*2));
        _block4.setLocation(x,y+size);
    }
}