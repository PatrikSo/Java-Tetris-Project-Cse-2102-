import javax.swing.*;
import java.awt.*;

public class TetrisApp extends JFrame{
    
    public TetrisApp(String title){
        super(title);
        //this.setSize(1024, 768);
        this.setResizable(false);
        this.setSize(TetrisConstants.BLOCK_SIZE*10, TetrisConstants.BLOCK_SIZE*20);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.add(new GamePanel());
        this.setVisible(true);
    }

    public static void main (String[] args){
        TetrisApp app = new TetrisApp("Tetris");
    }
}
