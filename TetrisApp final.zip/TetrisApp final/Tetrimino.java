
/**
 * Chapter 9: SmartEllipse.java
 * Adds capabilities to the Java2D.Double ellipse.
 * Same as the class defined in Chapter 7.
 */
import javax.swing.*;
import java.awt.*;

public abstract class Tetrimino
{
    private int _x, _y;
    private double _rotation;
    private final int STROKE_WIDTH = 2;
    //SmartRectangle _block1, _block2, _block3, _block4, _block5;
   
    
    protected SmartRectangle _block1 = new SmartRectangle(java.awt.Color.RED);
    protected SmartRectangle _block2 = new SmartRectangle(java.awt.Color.RED);
    protected SmartRectangle _block3 = new SmartRectangle(java.awt.Color.RED);
    protected SmartRectangle _block4 = new SmartRectangle(java.awt.Color.RED);
    
    public void fill (java.awt.Graphics2D aBrush){
        //filling in color for blocks 
        _block1.fill(aBrush);
        _block2.fill(aBrush);
        _block3.fill(aBrush);
        _block4.fill(aBrush);
    }
    public void draw (java.awt.Graphics2D aBrush) {
        //draw the blocks, set colors and border size
        aBrush.setColor(java.awt.Color.WHITE);
    	aBrush.setStroke(new BasicStroke(TetrisConstants.BLOCK_SIZE/15));
    	aBrush.draw(_block1);
        aBrush.draw(_block2);
        aBrush.draw(_block3);
        aBrush.draw(_block4);
    }
    public abstract void setLocation(int _x, int _y);
}
