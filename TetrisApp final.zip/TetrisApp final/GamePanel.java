import javax.swing.*;
import java.awt.*;


public class GamePanel extends JPanel{
    private Tetrimino  _tPiece;
    private Tetrimino  _zPiece;
    private Tetrimino  _oPiece;
    private Tetrimino  _lPiece;
    private Tetrimino  _iPiece;
    private Tetrimino  _jPiece;
    private Tetrimino  _sPiece;
    
    
    public GamePanel(){
        //_T1 = new T(150,150);
        
        //Very similar to Shapespanel
        //so the pieces get two int values
        //new because these are objects
        _tPiece = new T(TetrisConstants.BLOCK_SIZE*6,TetrisConstants.BLOCK_SIZE);

        _zPiece = new Z(TetrisConstants.BLOCK_SIZE*6, TetrisConstants.BLOCK_SIZE*9);

        _oPiece = new O(TetrisConstants.BLOCK_SIZE*2, TetrisConstants.BLOCK_SIZE*6);

        _lPiece = new L(TetrisConstants.BLOCK_SIZE, TetrisConstants.BLOCK_SIZE);

        _iPiece = new I(TetrisConstants.BLOCK_SIZE, TetrisConstants.BLOCK_SIZE*11);

        _jPiece = new J(TetrisConstants.BLOCK_SIZE*6, TetrisConstants.BLOCK_SIZE*12);

        _sPiece = new S(TetrisConstants.BLOCK_SIZE*6, TetrisConstants.BLOCK_SIZE*5);

    }
    public void paintComponent(java.awt.Graphics aBrush) {
        super.paintComponent(aBrush);
        java.awt.Graphics2D aBetterBrush = (java.awt.Graphics2D) aBrush;
        
        //draw and fill color
        
        //fill color
        _tPiece.fill(aBetterBrush);
        _zPiece.fill(aBetterBrush);
        _oPiece.fill(aBetterBrush);
        _lPiece.fill(aBetterBrush);
        _iPiece.fill(aBetterBrush);
        _jPiece.fill(aBetterBrush);
        _sPiece.fill(aBetterBrush);
        
        //draw color
        _tPiece.draw(aBetterBrush);
        _zPiece.draw(aBetterBrush);
        _oPiece.draw(aBetterBrush);
        _lPiece.draw(aBetterBrush);
        _iPiece.draw(aBetterBrush);
        _jPiece.draw(aBetterBrush);
        _sPiece.draw(aBetterBrush);
    }
}
