/**
 * Chapter 9: SmartEllipse.java
 * Adds capabilities to the Java2D.Double ellipse.
 * Same as the class defined in Chapter 7.
 */
public class T extends Tetrimino {
    //private int x, y;
    int size = TetrisConstants.BLOCK_SIZE;
    private java.awt.Color _purple = new java.awt.Color(102,0,153);

    public T(int x, int y){
        
        _block1 = new SmartRectangle(_purple);
        _block2 = new SmartRectangle(_purple);
        _block3 = new SmartRectangle(_purple);
        _block4 = new SmartRectangle(_purple);
       
        _block1.setSize(size,size);
        _block2.setSize(size,size);
        _block3.setSize(size,size);
        _block4.setSize(size,size);
           
        this.setLocation(x,y);
   
    }
 

    // more readable versions of methods provided by Java
    public void setLocation(int x, int y){
        //set location
        _block1.setLocation(x-size,y);
        _block2.setLocation(x,y);
        _block3.setLocation(x+size,y);
        _block4.setLocation(x,y+size);
    }
    
}
