/**
 * Chapter 9: SmartEllipse.java
 * Adds capabilities to the Java2D.Double ellipse.
 * Same as the class defined in Chapter 7.
 */
public class J extends Tetrimino {
    //private int x, y;
    int size = TetrisConstants.BLOCK_SIZE;
    private java.awt.Color _blue = new java.awt.Color(0,255,0);
    
    public J(int x, int y){
        //create blocks
        _block1 = new SmartRectangle(_blue);
        _block2 = new SmartRectangle(_blue);
        _block3 = new SmartRectangle(_blue);
        _block4 = new SmartRectangle(_blue);
       
        _block1.setSize(size,size);
        _block2.setSize(size,size);
        _block3.setSize(size,size);
        _block4.setSize(size,size);
           
        this.setLocation(x,y);
    }
 

    // more readable versions of methods provided by Java
    public void setLocation(int x, int y){
        //set location
        _block1.setLocation(x,y);
        _block2.setLocation(x,y + (size*2));
        _block3.setLocation(x-size,y + (size*2));
        _block4.setLocation(x,y+size);
    }
}