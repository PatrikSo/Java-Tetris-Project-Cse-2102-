import javax.swing.*;
import java.awt.*;

public class Lab1App extends JFrame{
    
    public Lab1App(String title){
        super(title);
        this.setSize(1024, 768);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.add(new ShapesPanel());
        this.setVisible(true);
    }

    public static void main (String[] args){
        Lab1App app = new Lab1App("Lab 1 Solution");
    }
}
