import javax.swing.*;
import java.awt.*;


public class ShapesPanel extends JPanel{
    private SmartEllipse _ellipse;
    private SmartEllipse _ellipse2;
    private SmartRectangle _rectangle;
    private SmartRectangle _diamond;
    private SmartRectangle _starp1;
    private SmartRectangle _starp2;
    private SmartPolygon _triangle;
    
    public ShapesPanel(){
        _ellipse = new SmartEllipse(java.awt.Color.MAGENTA);
        _ellipse.setLocation(200,200);
        _ellipse.setSize(50,50);
        
        _ellipse2 = new SmartEllipse(java.awt.Color.RED);
        _ellipse2.setLocation(150,150);
        _ellipse2.setSize(70,70);
        
        _rectangle = new SmartRectangle(java.awt.Color.BLUE);
        _rectangle.setLocation(100,100);
        _rectangle.setSize(50,50);
        
        _diamond = new SmartRectangle(java.awt.Color.GREEN);
        _diamond.setRotation(40);
        _diamond.setLocation(300,300);
        _diamond.setSize(55,55);
        
        
        _starp1 = new SmartRectangle(java.awt.Color.GRAY);
        _starp1.setLocation(900,100);
        _starp1.setSize(50,50);
        
        _starp2 = new SmartRectangle(java.awt.Color.GRAY);
        _starp2.setLocation(900,100);
        _starp2.setSize(50,50);
        _starp2.setRotation(40);
        
        int [] xPoints = {200,340,460};
        int [] yPoints = {460,560,520};
        _triangle = new SmartPolygon(java.awt.Color.YELLOW);
        _triangle.addPoint(xPoints[0],yPoints[0]);
        _triangle.addPoint(xPoints[1],yPoints[1]);
        _triangle.addPoint(xPoints[2],yPoints[2]);
        _triangle.getBounds();
        
        
    }
    public void paintComponent(java.awt.Graphics aBrush) {
        super.paintComponent(aBrush);
        java.awt.Graphics2D aBetterBrush = (java.awt.Graphics2D) aBrush;
        _ellipse.fill(aBetterBrush);
        _ellipse2.fill(aBetterBrush);
        _rectangle.fill(aBetterBrush);
        
        _starp1.fill(aBetterBrush);
        _starp2.fill(aBetterBrush);
        
        _diamond.fill(aBetterBrush);
        
        aBetterBrush.draw(_triangle);
        _triangle.fill(aBetterBrush);
    }
}
