/**
 * Lab 2 - MovingBallApp
 * Displays a window with a ball which bounces around the window. 
 */
import java.awt.*;
import javax.swing.*;
public class MovingBallApp extends javax.swing.JFrame {
  private BallPanel _theBallPanel;
  public MovingBallApp (String title) {
      // Instantiate the window with the specified title
      super(title);
      // Set the size of the window and the default close operaton
      this.setSize(600, 450);
      this.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
      // Instantiate the JPanel and add to the window
      _theBallPanel = new BallPanel();
      this.add(_theBallPanel);
      // Make the window visible
      this.setVisible(true);
  }

  public static void main (String [ ] args) {
    MovingBallApp app = new MovingBallApp ("CSE 2102 - Lab 2");
  }
}
