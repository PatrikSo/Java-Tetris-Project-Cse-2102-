/**
 * Lab 7 Task 1: BlockPanel.java
 * Creates the panel to be placed inside the BouncingSquareApp window.
 */
public class BallPanel extends javax.swing.JPanel  {
    // Declare component objects
    private BouncingBall _ball1;           
    private BouncingBall _ball2;
    
    public BallPanel () {
        // Instantiate the JPanel
        super();

        // Set the background to black
        this.setBackground(java.awt.Color.BLACK);
        // Instantiate the bouncing blocks
        _ball1 = new BouncingBall (new java.awt.Color(255,64,64), 10, this); 
        _ball2 = new BouncingBall (java.awt.Color.WHITE, 5, this);
        // Set the initial location and size of the block
        _ball1.setLocation(25, 35);
        _ball1.setSize(10, 10);
        _ball2.setLocation(150, 25);
        _ball2.setSize(10, 10);
    }

    public void paintComponent (java.awt.Graphics aBrush) {
        super.paintComponent(aBrush);
        java.awt.Graphics2D betterBrush = (java.awt.Graphics2D) aBrush;
        _ball1.fill(betterBrush);
        _ball2.fill(betterBrush);
    }
}
