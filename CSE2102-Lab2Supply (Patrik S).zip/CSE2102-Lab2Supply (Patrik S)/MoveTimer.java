/**
 * Lab 2: MoveTimer.java
 * A subclass of javax.swing.Timer that can be used for animation.
 * It also serves as an example of the code for an "event source" object.
 */
public class MoveTimer extends javax.swing.Timer {
    private Mover _mover; // peer object
    /**
     * Constructor for the MoveTimer
     */
    public MoveTimer (int anInterval, Mover aMover) {
       // Instantiate the timer with a particular interval
       super(anInterval, null);
       // Save the peer object
       _mover = aMover;
       // Register a new MoveListener with the MoveTimer
       MoveListener _moveListener = new MoveListener();
       this.addActionListener(_moveListener);
   }

   /**
    * Internal class - MoveListener
    */
   private class MoveListener implements java.awt.event.ActionListener {
       /**
        * The actionPerformed method specifies what is to me accomplished when 
        * the timer ticks
        */
        public void actionPerformed(java.awt.event.ActionEvent e){
            _mover.move();
        }
   }
}

