
/**
 * Write a description of class SnakeConstants here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SnakeConstants
{
    //the size of snake
    public static final int BLOCK_SIZE = 20;
}
