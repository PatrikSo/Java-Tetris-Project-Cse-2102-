
/**
 * Write a description of class Head here.
 * 
 * @author (Greg Johnson) 
 * @version (a version number or a date)
 */
import java.awt.Graphics2D;

public class Tail extends Body
{
    public Tail(){
		this(java.awt.Color.green);
	}
	public Tail(java.awt.Color c)
    {
		super(c);
    }
}
